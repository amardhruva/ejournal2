A Pen created at CodePen.io. You can find this one at https://codepen.io/bmarshall/pen/stDnB.

 Just a quick attempt to make a one-line search box that includes a text box and a button. The whole thing needs to fit in a fixed width and it's for a localized project so we need:

A) the search button to grow and shrink to accommodate for localized labels (which could be any width) and...

B) the input to grow and shrink to take up the rest of the space left over.

Wound up doing it using display: table and display: table-cell. box-sizing helped along the way.