# jUsualSlider
JQuery plugin for traditional slide show
* Ie8 +
* Supports touch
* Responsive (width in percent)
* Support auto sliding and stops auto sliding on mouseenter event and by public methods
* Can start sliding on any slider element
* Animation is set by css "transition" property
* Can contain any html-content
* <a href="http://somniatis.ru/demos/UsualSlider/" target="_blank">Demo & examples</a>
